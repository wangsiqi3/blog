// 5、用"模版继承"和"子模版"抽离 骨架、相同部分
// (1)头部和侧边栏要抽离到单独的文件header.art 和 aside.art 
// 然后在模版比如user.art里面 然后再把抽离出去的代码再通过模版语法{{include '模版路径./common/header.art'}} 引进来
// 为什么不用写绝对路径？ 因为这个路径是由模版引擎来解析的,不是浏览器来解析的,所以相对的就是当前文件比如user.art ; 而静态资源的外链文件是浏览器来解析的 如果写相对路径 是相对于浏览器的请求地址的 所以必须写绝对路径
// (2)模版的Html骨架抽离到单独的文件layout.art
// 给css js 和 主题部分填坑 用{{block 'link'}}{{/block}}  {{block 'main'}}{{/block}}  {{block 'script'}}{{/block}}  坑的名字分别叫link main script
// 继承的语法{{extend ''./common/layout.art}}  然后填坑{{block 'main'}}…主体代码…{{/block}}
// 6、实现登陆功能
//   (1)创建用户集合 初始化用户 a.连接数据库 b.创建用户集合 c.初始化用户
//   (2)为登录表单项设置请求地址、请求方式POST以及表单项name属性
//   (3)当用户点击登录按钮时，"客户端"验证用户是否填写了登录表单 如果其中一项没有输入，阻止表单提交 （在注册的时候才需要对邮箱的格式和密码的复杂度验证 登陆的时候不用验证）
//   (4)a."服务器"端接收请求参数，引入body-parser模块 b.二次验证用户是否填写了登录表单 如果其中一项没有输入，为客户端做出响应，阻止程序向下执行 c.跳到错误页面后 三秒后 跳回去登陆页面
//   (5)根据邮箱地址查询用户信息 如果用户不存在，为客户端做出响应，阻止程序向下执行  如果用户存在，将用户名和密码进行比对 比对成功，用户登录成功 比对失败，用户登录失败
//   (6)密码加密 密码绝对不能以明文存储很危险 所以要加密 这样用户信息才安全 
//      a.使用第三方模块cnpm install bcrypt(我安的是bcryptjs)    require导入 哈希密码是单程加密方式，只能加密，不能解密 1234=>abcd
//        需要依赖的其他环境(老师使用npm但我只能用cnpm才可以)：pathon 2x(计算机-环境变量-path); npm install node-gyp -g;npm install --global --production windows-build-tools 
//      b.在加密的密码中加入 生成的随机字符串，属于异步api生成promise对象，所以可以加个await使用返回值的方式接收（bcrypt.genSalt(10);）可以增加密码被破解的难度 
//      c.let pass = await bcrypt.hash('明文密码',salt);
//   (7)密码比对 let isValid = await bcrypt.compare('客户端传过来的明文密码','加密密码');  返回值是布尔类型
//   (8)保存登录状态  需要借组cookie与session 第三方模块npm install express-session  require导入
// 7、登陆拦截
//    没有登录的情况下 不能访问除了登陆页面的其他页面 需要用到express提供的中间件 要“写在路由之前”  拦截请求 判断用户登陆状态 如果是登陆的 放行 如果不是登陆 重定向到登陆页面
// 8、新增用户  ppt2.2  10个步骤
//    (6)使用第三方模块Joi:JavaScript对象的规则描述语言和验证器 用来验证对象格式 对请求参数的格式进行验证  npm install joi@14.3.1  版本太高不行  require引入 
// 9、数据分页 ppt2.3
// 10、用户信息修改 ppt2.4 点击修改按钮 跳转到user-edit页面 按时后面会有get参数id=_id  如果是添加用户 也是跳转到user-edit但后面不跟参数 所以就可以根据地址栏中有没有id参数判断是修改页面还是添加页面
// 11、删除用户 ppt2.5
// 12、文章管理  上传文件表单所以要用第三方模块formidable 
// 13、数据分页 ppt3.6  第三方模块mongoose-sex-page  npm install mongoose-sex-page   在article.js required导入
const express = require('express');
const path = require("path");
// 6、(4).a 接收post请求参数 引入body-parser模块 里面有个urlencoded方法({extended:false}) 拦截所有请求app.use
const bodyParser = require('body-parser');
// 6、(8)
const session = require('express-session');
// 12、导入第三方模块dateformat 怎么做到在模版文件中调用这个方法来格式化日期呢？导入art-template 然后12、A、向模版内导入dateformat变量
const dateFormat = require('dateformat');
const template = require('art-template');
// ppt2.6
const morgan = require('morgan');
// ppt2.7
const config = require('config');


const app = express();
// 6、(1).a
require('./model/connect');
// require('./model/user'); 初始化数据库后这句代码就不用了 不需要在app.js引用 而在路由中引用

// 6、(4).a
// 处理post请求参数 
// 注意：只能处理普通表单传过来的post请求参数 不能处理客户端传过来的二进制数据
app.use(bodyParser.urlencoded({ extended: false }));
// 12、
// 二进制数据要用第三方模块formidable：解析表单、支持get/post请求参数、文件上传  
// a.npm install formidable   在article-add.js里require引入formidable
// b.const form = new formidable.IncomingForm()创建表单解析对象
// c.form.uploadDir='/路径'设置文件上传路径（public-uploads文件夹）
// d.form.keepExtensions=true 保留表单上传文件的后缀  false就是不保留(默认)
// e.form.parse(req,(err,fields,files)=>{
//                     err错误对象 如果表单解析失败,err存放错误信息；表单解析成功 err将为空null
//                     fields 对象类型 存储普通表单数据
//                     files 对象类型 存储了和上传文件相关的数据
//               })

// 6、(8)   
app.use(session({
    secret: 'secret key',
    saveUninitialized: false,
    cookie: {
        // 毫秒
        maxAge: 24 * 60 * 60 * 1000
    }
}));
// saveUninitialized:false 意思就是说 当用户退出登陆的情况下不要保存cookie  登陆成功之后才保存cookie
// 不指定cookie的过期时间 当浏览器关闭 cookie就会自动被删除掉  而我希望关闭浏览器之后重新打开 还是登陆状态 一天之后不登陆才删除cookie


// 4、告诉express框架模版所在的位置  views
//    告诉express框架模版的默认后缀是什么 view engine
//    当渲染后缀为art的模版时 所使用的模版引擎是什么 app.engine('arr',require('express-art-template'))
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'art');
app.engine('art', require('express-art-template'));
// 12、A、向模版内导入dateformat变量 就可以格式化日期
template.defaults.imports.dateFormat = dateFormat;




// 3、开放静态资源文件 express有个static方法(接受静态资源存放目录)（要用绝对路径 所以要用到path）
// 开放之后比如在地址栏输入http://localhost/home/images/1.jpg 就可以打开了
app.use(express.static(path.join(__dirname, 'public')));

// ppt2.7
// config内部提供的get方法获取配置信息
console.log(config.get('title'));
// 如果produce.json里面有title属性 就读取produce里面的属性 没有的话就去读取default.json的


// ppt2.6
// 获取系统环境变量 返回值是对象process.env   然后我们要获取里面的NODE_ENV属性 
// console.log(process.env.NODE_ENV);
if (process.env.NODE_ENV == 'development') {
    // 当前是开发环境
    console.log('当前是开发环境');
    // 因为它同时也是express的中间件函数
    // 调用  在开发环境中，将客户端发送到服务器端的请求信息打印到控制台中 dev是固定的
    app.use(morgan('dev')); //GET /admin/login 304 7.571ms --
} else {
    // 当前是生产环境
    console.log('当前是生产环境');
}
// 如何将客户端的请求信息打印到控制台中呢？需要用到nodejs的一个第三方模块：npm install morgan require导入，同时它也是express的一个中间件函数

// 1、导入两个路由
const home = require('./route/home');
const admin = require('./route/admin');
const e = require('express');

// 7、登录拦截 单独挪到blog/middleware/loginGuard.js   middleware中间件的意思 Guard守卫的意思
app.use('/admin', require('./middleware/loginGuard'));
// 2、为路由匹配请求路径
app.use('/home', home);
app.use('/admin', admin)

// 错误处理中间件
app.use((err, req, res, next) => {
    // 与user-edit-fn.js相反的操作 将字符串对象转换为对象类型 JSON.parse();
    const result = JSON.parse(err);
    // res.redirect(`${result.path}?message=${result.message}`); 不能这样写死 因为?后面可能有很多个get参数 
    // 所以要通过for in 循环对象的方式进行 数组拼接.push()   .join方法是将数组里面的元素按照某一个字符进行拼接
    let params = [];
    for (let attr in result) {
        if (attr != 'path') {
            //attr + '=' + result[attr]; //message='密码比对失败，无法修改用户信息'
            params.push(attr + '=' + result[attr]);
        }
    }
    res.redirect(`${result.path}?${params.join('&')}`);
})

app.listen(80);
console.log('网站服务器启动成功,请访问localhost');