module.exports = (req, res) => {
    //  删除session   destroy方法
    req.session.destroy(function() {
        // 删除cookie  res下面的clearCookie方法   'connect.sid'是cookie的名字
        res.clearCookie('connect.sid');
        res.redirect('/admin/login');

        //bug就是登陆之后推出还是可以看到评论的输入框
        //所以退出登陆的时候也要清除article评论模版中的用户信息 
        req.app.locals.userInfo = null;
    });
}