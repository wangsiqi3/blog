const bcrypt = require('bcryptjs');
//6、(5) 导入用户集合构造函数  因为user.js导出的是个对象{ User } 所以用对象解构 
const { User } = require('../../model/user');
const login = async(req, res) => {
    // (4).a.  req.body可以接收post请求参数  但是需要用到第三方模块body-parser(命令行下载并到app.js引入)中的urlencode方法:app.use(urlencode方法({extended:false}))
    // res.send(req.body) //{"email":"709478618@qq.com","password":"123456"}
    // (4).b.  二次验证：A.解构 B.判断验证
    //    status()可以设置状态码400 因为send()方法内部把http状态码自动设置为200 但现在是出错了 return终止程序向下进行
    //    谷歌浏览器-设置-高级-（内容设置）网站设置-Javascript 的允许开关关掉 那么就不能执行javascript代码了
    const { email, password } = req.body;
    if (email.trim().length == 0 || password.trim().length == 0) {
        // return res.status(400).send('<h4>邮件地址或者密码错误</h4>');
        return res.status(400).render('admin/error', { msg: '邮件地址或者密码错误' });
    }
    // (4).c. 三秒后跳回登录页面 这需求很明显是页面跳转 不太适合在服务器端做 去到error.art中写客户端代码

    // 6、(5) 根据邮箱地址查询用户信息
    //    如果查询到了用户 user变量的值是对象类型，对象中存储的是用户信息 将客户端传递过来的密码和用户信息中的密码进行比对 
    //    如果没有查询到用户 user变量为空 渲染error页面
    // const user = await User.findOne({ email: email }); 属性和属性值一样 可以简写为下面这句
    const user = await User.findOne({ email });
    if (user) {
        // 6、(7)
        const isValid = await bcrypt.compare(password, user.password);
        if (isValid) {
            // 给req添加一个username属性 将用户名存储在请求对象req中 在浏览器中访问用户列表页面 把用户名显示在页面中 
            // 这个是为了证明： 因为http协议的无状态性  完成一次响应后客户端和服务端就断开了 所以登陆和无登陆没有区别 
            // req.username = user.username;
            // 6、(8)所以要实现真正的登陆 要建立客户端和服务器端的关联关系 需要借助其他技术cookie与session
            req.session.username = user.username;
            // 将用户角色存储在session对象中
            req.session.role = user.role;
            // c.app对象下面的locals对象 把数据放到locals对象里面 模版当中就可以直接拿到了 不需要通过res.render渲染到模版上了
            //   给locals下面添加一个属性userInfo 代表用户的信息
            //   不需要导入app对象 可以用req.add拿到 也就是app.js创建的那个app对象
            req.app.locals.userInfo = user;

            // 对用户的角色进行判断
            if (user.role == 'admin') {
                // 如果是管理员 就跳转到博客后台管理系统 也就是用户列表页面
                res.redirect('/admin/user');
            } else {
                res.redirect('/home/');
            }



        } else {
            res.status(400).render('admin/error', { msg: '邮件地址或者密码错误' });
        }
    } else {
        res.status(400).render('admin/error', { msg: '邮件地址或者密码错误' });
    }
}

module.exports = login;
// 也可以不要这句 直接写module.exports = async(req, res) => {……}   更简洁