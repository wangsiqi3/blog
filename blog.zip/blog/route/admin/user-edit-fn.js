const { User, validateUser } = require('../../model/user');
const bcrypt = require('bcryptjs');
module.exports = async(req, res, next) => {
    // 6、(4) 接受传递过来的post参数
    // res.send(req.body);
    // req.body是对象 所以刚好可以用来做验证

    // 8、(6)
    // a.验证代码优化
    // 对象的验证规则 被放到use.js里面
    try {
        // 验证 也被放到use.js
        // validateUser(req.body);这个函数返回的是一个promise对象 所以可以用await
        await validateUser(req.body);
    } catch (e) {
        // 验证没有通过
        // 重定向回客户添加页面
        // return res.redirect(`/admin/user-edit?message=${e.message}`);
        // b.错误处理优化 express给我们一个错误处理中间件 写在app.js里面
        // next代码只能传递一个参数 而且必须是字符串类型，
        // 所以要把对象 转换成字符串JSON.stringify(对象) 而且我们现在要传递两个参数（重定向地址、错误信息）要怎么做？
        // 调用next方法就会 触发 错误处理中间件  因为传参了 传的参数就相当于错误处理中间件四个参数中的err
        return next(JSON.stringify({ path: '/admin/user-edit', message: e.message }));
    }

    // 8、(7)   验证通过 执行下面代码
    //   a.引入用户集合构造函数User  解构出来
    //   b.根据邮箱地址查询用户是否存在findOne  如果找不到返回值是空，找得到返回值就是那个用户信息对象
    let user = await User.findOne({ email: req.body.email });
    if (user) {
        // 重定向回客户添加页面
        // return res.redirect(`/admin/user-edit?message=邮箱地址已经被占用`);
        // 错误处理优化
        return next(JSON.stringify({ path: '/admin/user-edit', message: '邮箱地址已经被占用' }));
    }
    // 8、(8) 如果邮箱地址没被占用 就对密码加密操作 bcrypt 将用户信息添加到数据库当中
    const salt = await bcrypt.genSalt(10)
    const password = await bcrypt.hash(req.body.password, salt);
    // 加密后的密码替换掉原来的密码
    req.body.password = password;
    // 添加到数据库
    await User.create(req.body);
    // 将页面定向到用户列表页面
    res.redirect('/admin/user');

}