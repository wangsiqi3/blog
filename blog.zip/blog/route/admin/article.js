const pagination = require('mongoose-sex-page'); //13、实现分页
const { Article } = require('../../model/article');
module.exports = async(req, res) => {
    // 13、接受客户端传递过来的页码
    const page = req.query.page;

    // 12、添加标识.locals.currentLink 标识当前访问的是文章列表页面 判断aside里面两个a要选中那个a去添加类名active
    req.app.locals.currentLink = 'article';

    // 12、
    // 查询所有文章数据 返回给articles  
    // 然后传给模板article.art 在模板里面循环传过去的这个查询出来的数组articles 就能展示在页面了
    // let articles = await Article.find().populate('author');   //articles是个数组[]
    // 13、 pagination(集合构造函数).page()....
    //page代表当前页  size每一页显示的数据条数  display客户端一次向要显示的页码数量  exec向数据库发送查询请求
    let articles = await pagination(Article).find().page(page).size(2).display(3).populate('author').exec();
    //这时候articles是个对象 articles对象下面有个records属性：[]
    // res.send(articles);
    res.render('admin/article.art', {
        articles: articles
    });
    // 作者的处理
    // 但是这样articles.author显示出来是User里面的_id  所以要用到多集合联合查询populate('author'); 这样author就从存储_id 变成存储_id对应的作者的详细信息 也就一整个User对象
    // 所以articles.author就变成了一个对象 对象里面有个username代表用户的名字 所以要到模版里面加上.username
    // 发布时间的处理
    // 格式化日期 用到第三方模块dateformat  npm install dateformat
}