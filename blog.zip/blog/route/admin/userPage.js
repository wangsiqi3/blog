const { User } = require('../../model/user');
module.exports = async(req, res) => {
    // 12、添加标识.locals.currentLink 标识当前访问的是用户管理页面 判断aside里面两个a要选中那个a去添加类名active
    req.app.locals.currentLink = 'user';

    // 9、数据分页 1.2
    //    a.接收客户端传递过来的当前页参数res.query.page
    //    b.总页数let total = 查询数据总条数let count = await User.countDocument({})/每页显示的数据条数let pagesize =  ; 向上取整：Math.ceil
    //    c.分页功能需要用到两个方法：limit(pagesize)限制查询数量传入每页显示的数据数量  skip(start)跳过多少条数据传入显示数据的开始位置（索引号）
    //    d.数据开始查询的位置start = （当前页码page-1）*pagesize
    let page = req.query.page || 1; //|| 1 表示没有传页码的时候默认第一页
    let pagesize = 3;
    let count = await User.countDocuments({});
    let total = Math.ceil(count / pagesize);
    let start = (page - 1) * pagesize;
    let users = await User.find({}).limit(pagesize).skip(start);
    // 9、 3.生成分页器
    //     

    // let users = await User.find();
    res.render('admin/user', {
        users: users,
        // 9、3. 需要把总页数和当前页码传给模版  注意：-有隐式对象转换 但是+没有 所以先-0再去计算加法运算 就正常  block会破坏原有样式 display:inline也可以显示
        total: total,
        page: page
    });
    // @表示原文输出 
}

// msg:req.name  用户 该用户不存在
// 6、(8)
// a.我们还要把用户名显示在头部的右上角 但是头部是公共的  所以我们不能单纯的只在user页面写上用户名 因为跳转到其他页面的头部也要显示这个用户名 
// b.那每一个页面都要重复写这个代码 很麻烦  
// , {msg: req.session.username} //用户 iteheima
// c.如何把一些公共的数据暴露到模版当中呢? 
//   app对象下有一个对象叫locals 把数据放到locals对象里面 模版当中就可以直接拿到了 不需要通过res.render渲染到模版上了