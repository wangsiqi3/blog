module.exports = (req, res) => {
    // render(路径)渲染登陆页面
    res.render('admin/login');
}