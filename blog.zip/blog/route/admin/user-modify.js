const { User } = require('../../model/user');
const bcrypt = require('bcryptjs');
module.exports = async(req, res, next) => {
    // 10、
    // req.query才能拿到id 
    // req.body拿到的是post的
    // 密码比对 因为是加密过 所以要用到第三方模块bcrypt下的compare方法（明文密码，数据库中存储的加密过得密码）  比对成功返回true
    // A.
    const { username, email, role, state, password } = req.body;

    const id = req.query.id
    const user = await User.findOne({ _id: id });
    const isValid = await bcrypt.compare(password, user.password);
    if (isValid) {
        // res.send('密码比对成功');
        // 将用户修改后的信息更新到数据库中 注意：密码不修改,还是保持那个加密的密码 所以第二个参数像下面这样不能直接写req.body 
        // let user = await User.updateOne({_id:id},req.body);
        // 下面这样写又太麻烦 所以我们可以再上面A.先解构出来
        // await User.updateOne({_id:id}, {
        //     username : body.username,
        //     email: body.email,
        //     role : body.role,
        //     state: body.state
        // });
        await User.updateOne({ _id: id }, {
            username: username,
            email: email,
            role: role,
            state: state
        });
        // 将页面重定向回用户列表页面
        res.redirect('/admin/user');
    } else {
        let obj = {
            path: '/admin/user-edit',
            message: '密码比对失败，无法修改用户信息',
            id: id //要传id 因为重定向回修改页面的时候仍然需要id来渲染信息进去表单
        }
        next(JSON.stringify(obj));
    }
}