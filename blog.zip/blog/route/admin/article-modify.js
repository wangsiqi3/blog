// 12、
// 引入formidable第三方模块 1.new一个表单解析对象  2.uploadDir=上传文件的存放位置（public-uploads），使用绝对路径  3.保留上传文件的后缀.keepExtensions=true   4解析表单.parse(req,()=>{})
const { Article } = require('../../model/article');
const formidable = require('formidable');
const path = require('path');

module.exports = (req, res) => {
    const { id } = req.query;
    // res.send(id);
    const form = new formidable.IncomingForm();
    form.uploadDir = path.join(__dirname, '../', '../', 'public', 'uploads');
    form.keepExtensions = true; //true 上传到uploads的图片就是有后缀的 就能正常显示
    form.parse(req, async(err, fields, files) => {
        // res.send(files.cover.path); // C:\\Users\\Administrator\\Desktop\\qianduan\\6.qianhouduanjiaohu\\1.node+express\\day6\\code\\blog\\public\\uploads\\upload_c48eed721b4516c931be4c27bf6236c1.jpg
        // 上面这行实际上就是“服务器端电脑”上的绝对路径  只在服务器端电脑上好使  在客户端上不好使
        // 所以我们只需要A、截取uploads\\upload_c48eed721b4516c931be4c27bf6236c1.jpg 因为客户端地址栏/就是绝对路径 就是public了

        // A、调用split('字符串分隔符') 我们用public作为分割符 然后分割出一个数组的两个元素 我们要取后半段 所以是取数组的第二个元素也就是[1]  
        // res.send(files.cover.path.split('public')[1]); // \uploads\upload_8956fc82bd9ef70b4fc4cccbf72a621e.jpg

        // 像文章集合Article中插入数据
        await Article.updateOne({ _id: id }, {
            title: fields.title,
            publishDate: fields.publishDate,
            cover: files.cover.path.split('public')[1],
            content: fields.content,
        });
        // 将页面重定向到文章列表页面
        res.redirect('/admin/article');
    })

}