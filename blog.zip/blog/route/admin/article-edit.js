const { Article } = require("../../model/article");

module.exports = async(req, res) => {
    // 12、添加标识.locals.currentLink 标识当前访问的是文章管理页面 判断aside里面两个a要选中那个a去添加类名active
    req.app.locals.currentLink = 'article';
    const { id } = req.query;

    if (id) {
        let article = await Article.findOne({ _id: id }).populate('author');
        res.render('admin/article-edit', {
            article: article,
            // link属性存放当前这个表单要跳转的地址
            // link: '/admin/article-modify?id=' + id,
            link: '/admin/article-modify?id=' + id,
            // link: `/admin/user-modify?id=${id}`, 这样写什么不行？
            // button属性存放 提交按钮的value值  修改
            button: '修改'
        });
    } else {
        // res.send('ok');
        // 8、 新增用户(6)
        //req.query是get参数 是个对象 解构message出来 message是验证后的错误信息
        res.render('admin/article-edit', {
            // link属性存放当前这个表单要跳转的地址
            link: '/admin/article-add',
            // button属性存放 提交按钮的value值  添加
            button: '添加'
        });
    }

}