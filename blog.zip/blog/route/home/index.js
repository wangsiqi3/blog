// 导入文章集合构造函数
const { Article } = require('../../model/article');
// 分页 所以要导入第三方模块mongoose-sex-page
const pagination = require('mongoose-sex-page');
module.exports = async(req, res) => {
    const page = req.query.page;
    // 一、从数据库中查询数据

    // 1、.find方法查询数据 是异步操作 所以要await 
    // let result = await Article.find();  //author是一个id号  result是一个[]
    // 因为author所以要用到多集合联合查询 所以要用到pupulate方法
    // 2、分页 page(1).size(4).display(5) 记得最后不要忘记exec() 必须有这个 才能实现分页
    let result = await pagination(Article).page(page).size(4).display(5).find().populate('author').exec(); //author是一个对象 里面有作者的详细信息 username就是作者名字    result是一个对象{}
    // res.send(result);
    // res.send('欢迎来到博客首页');

    // 二、渲染模块并传递数据
    res.render('home/default.art', {
        result: result
    });
}