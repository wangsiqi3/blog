// 评论添加功能
const { Comment } = require('../../model/comment');
module.exports = async(req, res) => {

    // 1、接受客户端传递过来的请求参数
    // res.send(req.body); //{"content":"","uid":"5f324b393f8adc217805c761","aid":"5f2e3ef6d5df112a5801a159"}
    const { content, uid, aid } = req.body;

    // 2、将评论信息存储到数据库的评论集合中
    await Comment.create({
        content: content,
        uid: uid,
        aid: aid,
        time: new Date()
    });

    // 3、将页面重定向回文章详情页面
    res.redirect('/home/article?id=' + aid);


}