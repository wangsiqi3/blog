const { Article } = require("../../model/article");

// const { Article } = require('../../model/article');  为什么写了这个反而会出错？
const { Comment } = require('../../model/comment');
module.exports = async(req, res) => {
    // 接受客户端传过来的文章id值
    const id = req.query.id;
    let article = await Article.findOne({ _id: id }).populate('author');

    // 评论展示功能
    // 1、查询当前文章所对应的评论信息
    let comments = await Comment.find({ aid: id }).populate('uid');
    // res.send(comments);
    // res.send(article);
    // res.send('欢迎来到博客文章详情页面');
    res.render('home/article.art', {
        article: article,
        comments: comments
    });
}