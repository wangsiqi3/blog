// 导入bcrypt
const bcrypt = require('bcrypt');

async function run() {
    // 生成随机字符串
    // genSalt方法接收一个数值作为参数
    // 数值越大，生成的随机字符串复杂度越高， 数值越小 生成的随机字符串复杂度越低  默认值是10
    // 生成的随机字符串，属于异步api生成promise对象，所以可以加个await使用返回值的方式接收 那么就要把代码放在一个异步函数里面
    const salt = await bcrypt.genSalt(10);
    // 对密码进行加密：bcrypt.hash('要进行加密的明文','随机字符串')  返回值是加密后的密码
    const result = await bcrypt.hash('123456', salt);
    console.log(salt);
    console.log(result);
}
run();