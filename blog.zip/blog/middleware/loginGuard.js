module.exports = guard = (req, res, next) => {
    // 如果用户不是登陆状态
    if (req.url != '/login' && !req.session.username) {
        res.redirect('/admin/login');
    } else {
        // 如果用户是是登陆状态并且是一个普通用户normal 就让它跳转到博客首页 阻止程序向下执行
        // 在login.js中先将用户对象存储在session中
        if (req.session.role == 'normal') {
            return res.redirect('/home/')
        }
        next();
    }
}

// module.exports = guard;
// app.js里面的require('./middleware/loginGuard')  得到的返回值就是module.exports 也就是guard函数
// 也可以不要这句 直接写module.exports = async(req, res) => {……}   更简洁