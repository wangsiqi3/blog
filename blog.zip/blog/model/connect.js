const mongoose = require('mongoose');
// mongoose.connect('mongodb://localhost/blog', { useNewUrlParser: true, useUnifiedTopology: true })
//     .then(() => console.log('数据库连接成功'))
//     .catch(err => console.log(err, '数据库连接失败'));

// 导入config模块
// 使用反引号 因为要进行字符串拼接
const config = require('config');
// console.log(config.get('db.host'))  我为什么写了这个没反应？老师写了之后命令行有输出
mongoose.connect(`mongodb://${config.get('db.user')}:${config.get('db.pwd')}@${config.get('db.host')}:${config.get('db.port')}/${config.get('db.name')}`, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('数据库连接成功'))
    .catch(err => console.log(err, '数据库连接失败'));