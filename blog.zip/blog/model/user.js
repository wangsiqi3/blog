const Joi = require('joi');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
// 1、创建用户集合规则
const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        minlength: 2,
        maxlength: 20
    },
    email: {
        type: String,
        // 要用邮箱地址登陆 所以要保证邮箱地址唯一不重复 数据库里面有这个邮箱就不让你插入了 
        unique: true,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    role: {
        // 我们自己规定 admin 超级管理员 normal 普通用户
        type: String,
        required: true
    },
    state: {
        type: Number,
        // 我们自己规定 0是启用状态 1是禁用状态 让它默认为0
        default: 0
    }
});
// 2、创建集合
const User = mongoose.model('User', userSchema);

// 3、初始化集合 User.create({})  创建完了就要注释掉 不然下一次运行又会创建 又因为邮箱只能唯一 所以会报错
async function createUser() {
    // 6、(6)
    const salt = await bcrypt.genSalt(10);
    const pass = await bcrypt.hash('123456', salt);
    const user = await User.create({
        username: 'iteheima',
        email: 'itheima@itcast.cn',
        password: pass,
        role: 'admin',
        state: 0
    })

}
// createUser();

//验证用户信息
const validateUser = user => {
    // 对象的验证规则 放到use.js里面
    const schema = {
        // valid有合法的验证通过的意思 valid(合法的值,合法的值)传递valid（）以外的值都不合法
        username: Joi.string().min(2).max(12).required().error(new Error('用户名不符合验证规则')),
        email: Joi.string().email().required().error(new Error('邮箱格式不符合要求')),
        password: Joi.string().regex(/^[a-zA-Z0-9]{3,30}$/).required().error(new Error('密码格式不符合要求')),
        role: Joi.string().valid('normal', 'admin').required().error(new Error('角色值非法')),
        state: Joi.string().valid('0', '1').required().error(new Error('状态值非法'))
    }
    return Joi.validate(user, schema); //return一个promise对象
}


// module.exports = User; 因为后面可能还要开放一些其他东西 所以改成开放一个对象 
// module.exports = { User: User }; 属性和属性值一样 可以简写为下面这一句
module.exports = {
    User,
    validateUser
};