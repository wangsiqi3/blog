const Joi = require('joi');
// 定义对象的验证规则
const schema = {
    // error可以自定义错误信息
    username: Joi.string().min(2).max(5).required().error(new Error('username属性没有通过验证')),
    birth: Joi.number().min(1900).max(2020).error(new Error('birth没有通过验证')),
};

async function run() {
    // 验证有通过和不通过 不通过会抛出异常 所以用try catch
    try {
        await Joi.validate({ username: 'ab', birth: 1800 }, schema);
        // await Joi.validate({}, schema); //验证成功 证明了规则里面所有属性都是可选属性 也就是说你验证的对象中可以没有这个属性
        //但是在规则里面加上required()之后就变成必传属性 不然不通过验证   
    } catch (ex) {
        console.log(ex.message);
        return;
    }
    console.log("验证通过");
};
run();